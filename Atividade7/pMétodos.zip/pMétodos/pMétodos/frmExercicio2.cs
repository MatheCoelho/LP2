﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMétodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void BtnVerifica_Click(object sender, EventArgs e)
        {
            if(string.Compare(txtBoxPalavra1.Text, txtBoxPalavra2.Text, true) == 0)
            {
                MessageBox.Show("São iguais");
            }
            else
            {
                MessageBox.Show("São diferentes");
            }
        }

        private void BtnInserir1_Click(object sender, EventArgs e)
        {
            int metade = txtBoxPalavra2.Text.Length / 2;

            txtBoxPalavra2.Text = txtBoxPalavra2.Text.Substring(0, metade) +
                txtBoxPalavra1.Text + txtBoxPalavra2.Text.Substring(metade,
                txtBoxPalavra2.Text.Length - metade);
        }

        private void BtnInserir2_Click(object sender, EventArgs e)
        {
            int metade = txtBoxPalavra1.Text.Length / 2;

            txtBoxPalavra2.Text = txtBoxPalavra1.Text.Insert(metade, "**");
        }
    }
}
