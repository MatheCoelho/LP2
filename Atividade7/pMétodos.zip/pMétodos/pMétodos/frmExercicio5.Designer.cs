﻿namespace pMétodos
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtboxNum1 = new System.Windows.Forms.TextBox();
            this.txtboxNum2 = new System.Windows.Forms.TextBox();
            this.lbl1Num = new System.Windows.Forms.Label();
            this.lbl2Num = new System.Windows.Forms.Label();
            this.btnSorteio = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtboxNum1
            // 
            this.txtboxNum1.Location = new System.Drawing.Point(460, 93);
            this.txtboxNum1.Name = "txtboxNum1";
            this.txtboxNum1.Size = new System.Drawing.Size(349, 26);
            this.txtboxNum1.TabIndex = 0;
            // 
            // txtboxNum2
            // 
            this.txtboxNum2.Location = new System.Drawing.Point(460, 159);
            this.txtboxNum2.Name = "txtboxNum2";
            this.txtboxNum2.Size = new System.Drawing.Size(349, 26);
            this.txtboxNum2.TabIndex = 1;
            // 
            // lbl1Num
            // 
            this.lbl1Num.AutoSize = true;
            this.lbl1Num.Location = new System.Drawing.Point(372, 99);
            this.lbl1Num.Name = "lbl1Num";
            this.lbl1Num.Size = new System.Drawing.Size(84, 20);
            this.lbl1Num.TabIndex = 2;
            this.lbl1Num.Text = "1º Número";
            // 
            // lbl2Num
            // 
            this.lbl2Num.AutoSize = true;
            this.lbl2Num.Location = new System.Drawing.Point(376, 165);
            this.lbl2Num.Name = "lbl2Num";
            this.lbl2Num.Size = new System.Drawing.Size(84, 20);
            this.lbl2Num.TabIndex = 3;
            this.lbl2Num.Text = "2º Número";
            // 
            // btnSorteio
            // 
            this.btnSorteio.Location = new System.Drawing.Point(569, 265);
            this.btnSorteio.Name = "btnSorteio";
            this.btnSorteio.Size = new System.Drawing.Size(127, 49);
            this.btnSorteio.TabIndex = 4;
            this.btnSorteio.Text = "Realiza sorteio";
            this.btnSorteio.UseVisualStyleBackColor = true;
            this.btnSorteio.Click += new System.EventHandler(this.BtnSorteio_Click);
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1213, 492);
            this.Controls.Add(this.btnSorteio);
            this.Controls.Add(this.lbl2Num);
            this.Controls.Add(this.lbl1Num);
            this.Controls.Add(this.txtboxNum2);
            this.Controls.Add(this.txtboxNum1);
            this.Name = "frmExercicio5";
            this.Text = "frmExercicio5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtboxNum1;
        private System.Windows.Forms.TextBox txtboxNum2;
        private System.Windows.Forms.Label lbl1Num;
        private System.Windows.Forms.Label lbl2Num;
        private System.Windows.Forms.Button btnSorteio;
    }
}