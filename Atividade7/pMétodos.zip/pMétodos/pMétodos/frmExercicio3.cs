﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMétodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void BtnRemove1_Click(object sender, EventArgs e)
        {
            int posicao = txtBoxPalavra2.Text.IndexOf(txtBoxPalavra1.Text, StringComparison.OrdinalIgnoreCase);

            while(posicao >= 0)
            {
                txtBoxPalavra2.Text = txtBoxPalavra2.Text.Substring(0, posicao) +
                    txtBoxPalavra2.Text.Substring(posicao + txtBoxPalavra1.Text.Length,
                    txtBoxPalavra2.Text.Length - posicao - txtBoxPalavra1.Text.Length);

                posicao = txtBoxPalavra2.Text.IndexOf(txtBoxPalavra1.Text, StringComparison.OrdinalIgnoreCase);
            }

        }

        private void BtnRemove2_Click(object sender, EventArgs e)
        {
            txtBoxPalavra2.Text = txtBoxPalavra2.Text.Replace(txtBoxPalavra1.Text, "");
        }

        private void BtnInverte_Click(object sender, EventArgs e)
        {
            //transformando string em array
            char[] vetor = txtBoxPalavra1.Text.ToCharArray();
            //inverte o array
            Array.Reverse(vetor);
            txtBoxPalavra2.Text = "";
            //voltar vetor para string
            foreach (var c in vetor)
                txtBoxPalavra2.Text += c;
        }
    }
}
