﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtboxLado1_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtboxLado1, "");
            double lado1;

            if(!double.TryParse(txtboxLado1.Text, out lado1))
            {
                errorProvider1.SetError(txtboxLado1, "Lado 1 inválido!");
            }
        }

        private void TxtboxLado2_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtboxLado2, "");
            double lado2;

            if (!double.TryParse(txtboxLado2.Text, out lado2))
            {
                errorProvider2.SetError(txtboxLado2, "Lado 2 inválido!");
            }
        }

        private void TxtboxLado3_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txtboxLado3, "");
            double lado1;

            if (!double.TryParse(txtboxLado3.Text, out lado1))
            {
                errorProvider1.SetError(txtboxLado3, "Lado 3 inválido!");
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            double lado1, lado2, lado3;

            if (!double.TryParse(txtboxLado1.Text, out lado1) ||
                !double.TryParse(txtboxLado2.Text, out lado2) ||
                !double.TryParse(txtboxLado3.Text, out lado3))
               {
                MessageBox.Show("Valores devem ser números!");
            }
            else
            {
                if (lado1 < (lado2 + lado3) && lado1 >
                    Math.Abs(lado2 - lado3) && lado2 < (lado1 + lado3)
                    && lado2 > Math.Abs(lado1 - lado3) 
                    && lado3 < (lado1 + lado2) &&
                    lado3 > Math.Abs(lado1 - lado2))
                {
                    if(lado1 == lado2 && lado2 == lado3)
                        MessageBox.Show($"Os valores {lado1}, {lado2} e {lado3} formam um triângulo equilátero");
                    else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3)
                        MessageBox.Show($"Os valores {lado1}, {lado2} e {lado3} formam um triângulo isóceles");
                    else
                        MessageBox.Show($"Os valores {lado1}, {lado2} e {lado3} formam um triângulo escaleno");
                }
                else
                    MessageBox.Show($"Os valores {lado1}, {lado2} e {lado3} não formam um triângulo");
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            txtboxLado1.Clear();
            txtboxLado2.Clear();
            txtboxLado3.Clear();
            errorProvider1.SetError(txtboxLado1, "");
            errorProvider2.SetError(txtboxLado2, "");
            errorProvider3.SetError(txtboxLado3, "");
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
