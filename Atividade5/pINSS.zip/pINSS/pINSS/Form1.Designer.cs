﻿namespace pINSS
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.NumUpDownFilhos = new System.Windows.Forms.NumericUpDown();
            this.mskboxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.mskboxNomeFunc = new System.Windows.Forms.MaskedTextBox();
            this.lblNomeFunc = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.txtboxAliqINSS = new System.Windows.Forms.TextBox();
            this.txtboxAliqIRPF = new System.Windows.Forms.TextBox();
            this.txtboxSalFamilia = new System.Windows.Forms.TextBox();
            this.txtboxDescIRPF = new System.Windows.Forms.TextBox();
            this.txtboxDescINSS = new System.Windows.Forms.TextBox();
            this.txtboxSalLiquido = new System.Windows.Forms.TextBox();
            this.lblAliqINSS = new System.Windows.Forms.Label();
            this.lblAliqIRPF = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnSair = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.NumUpDownFilhos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            this.SuspendLayout();
            // 
            // NumUpDownFilhos
            // 
            this.NumUpDownFilhos.Location = new System.Drawing.Point(154, 89);
            this.NumUpDownFilhos.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.NumUpDownFilhos.Name = "NumUpDownFilhos";
            this.NumUpDownFilhos.Size = new System.Drawing.Size(120, 20);
            this.NumUpDownFilhos.TabIndex = 2;
            // 
            // mskboxSalBruto
            // 
            this.mskboxSalBruto.Location = new System.Drawing.Point(154, 53);
            this.mskboxSalBruto.Name = "mskboxSalBruto";
            this.mskboxSalBruto.Size = new System.Drawing.Size(120, 20);
            this.mskboxSalBruto.TabIndex = 1;
            this.mskboxSalBruto.Validated += new System.EventHandler(this.mskboxSalBruto_Validated);
            // 
            // mskboxNomeFunc
            // 
            this.mskboxNomeFunc.Location = new System.Drawing.Point(154, 24);
            this.mskboxNomeFunc.Name = "mskboxNomeFunc";
            this.mskboxNomeFunc.Size = new System.Drawing.Size(343, 20);
            this.mskboxNomeFunc.TabIndex = 0;
            this.mskboxNomeFunc.Validated += new System.EventHandler(this.mskboxNomeFunc_Validated);
            // 
            // lblNomeFunc
            // 
            this.lblNomeFunc.AutoSize = true;
            this.lblNomeFunc.Location = new System.Drawing.Point(40, 27);
            this.lblNomeFunc.Name = "lblNomeFunc";
            this.lblNomeFunc.Size = new System.Drawing.Size(108, 13);
            this.lblNomeFunc.TabIndex = 5;
            this.lblNomeFunc.Text = "Nome do Funcionário";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Location = new System.Drawing.Point(81, 56);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(67, 13);
            this.lblSalBruto.TabIndex = 6;
            this.lblSalBruto.Text = "Salário Bruto";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Location = new System.Drawing.Point(62, 91);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(86, 13);
            this.lblNumFilhos.TabIndex = 7;
            this.lblNumFilhos.Text = "Número de filhos";
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(207, 178);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(141, 41);
            this.btnVerificar.TabIndex = 3;
            this.btnVerificar.Text = "Verificar desconto";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // txtboxAliqINSS
            // 
            this.txtboxAliqINSS.Enabled = false;
            this.txtboxAliqINSS.Location = new System.Drawing.Point(151, 278);
            this.txtboxAliqINSS.Name = "txtboxAliqINSS";
            this.txtboxAliqINSS.Size = new System.Drawing.Size(100, 20);
            this.txtboxAliqINSS.TabIndex = 9;
            // 
            // txtboxAliqIRPF
            // 
            this.txtboxAliqIRPF.Enabled = false;
            this.txtboxAliqIRPF.Location = new System.Drawing.Point(151, 311);
            this.txtboxAliqIRPF.Name = "txtboxAliqIRPF";
            this.txtboxAliqIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtboxAliqIRPF.TabIndex = 10;
            // 
            // txtboxSalFamilia
            // 
            this.txtboxSalFamilia.Enabled = false;
            this.txtboxSalFamilia.Location = new System.Drawing.Point(151, 350);
            this.txtboxSalFamilia.Name = "txtboxSalFamilia";
            this.txtboxSalFamilia.Size = new System.Drawing.Size(100, 20);
            this.txtboxSalFamilia.TabIndex = 11;
            // 
            // txtboxDescIRPF
            // 
            this.txtboxDescIRPF.Enabled = false;
            this.txtboxDescIRPF.Location = new System.Drawing.Point(360, 314);
            this.txtboxDescIRPF.Name = "txtboxDescIRPF";
            this.txtboxDescIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtboxDescIRPF.TabIndex = 12;
            // 
            // txtboxDescINSS
            // 
            this.txtboxDescINSS.Enabled = false;
            this.txtboxDescINSS.Location = new System.Drawing.Point(360, 278);
            this.txtboxDescINSS.Name = "txtboxDescINSS";
            this.txtboxDescINSS.Size = new System.Drawing.Size(100, 20);
            this.txtboxDescINSS.TabIndex = 13;
            // 
            // txtboxSalLiquido
            // 
            this.txtboxSalLiquido.Enabled = false;
            this.txtboxSalLiquido.Location = new System.Drawing.Point(360, 353);
            this.txtboxSalLiquido.Name = "txtboxSalLiquido";
            this.txtboxSalLiquido.Size = new System.Drawing.Size(100, 20);
            this.txtboxSalLiquido.TabIndex = 14;
            // 
            // lblAliqINSS
            // 
            this.lblAliqINSS.AutoSize = true;
            this.lblAliqINSS.Location = new System.Drawing.Point(69, 281);
            this.lblAliqINSS.Name = "lblAliqINSS";
            this.lblAliqINSS.Size = new System.Drawing.Size(77, 13);
            this.lblAliqINSS.TabIndex = 15;
            this.lblAliqINSS.Text = "Alíquiota INSS";
            // 
            // lblAliqIRPF
            // 
            this.lblAliqIRPF.AutoSize = true;
            this.lblAliqIRPF.Location = new System.Drawing.Point(72, 314);
            this.lblAliqIRPF.Name = "lblAliqIRPF";
            this.lblAliqIRPF.Size = new System.Drawing.Size(74, 13);
            this.lblAliqIRPF.TabIndex = 16;
            this.lblAliqIRPF.Text = "Alíquota IRPF";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(70, 353);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(76, 13);
            this.lblSalFamilia.TabIndex = 17;
            this.lblSalFamilia.Text = "Salário Família";
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.Location = new System.Drawing.Point(276, 356);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(78, 13);
            this.lblSalLiquido.TabIndex = 18;
            this.lblSalLiquido.Text = "Salário Líquido";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Location = new System.Drawing.Point(273, 281);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(81, 13);
            this.lblDescINSS.TabIndex = 19;
            this.lblDescINSS.Text = "Desconto INSS";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Location = new System.Drawing.Point(274, 317);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(80, 13);
            this.lblDescIRPF.TabIndex = 20;
            this.lblDescIRPF.Text = "Desconto IRPF";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.Red;
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Location = new System.Drawing.Point(307, 435);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(92, 32);
            this.btnSair.TabIndex = 5;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(154, 435);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(84, 32);
            this.btnLimpar.TabIndex = 4;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(560, 502);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblAliqIRPF);
            this.Controls.Add(this.lblAliqINSS);
            this.Controls.Add(this.txtboxSalLiquido);
            this.Controls.Add(this.txtboxDescINSS);
            this.Controls.Add(this.txtboxDescIRPF);
            this.Controls.Add(this.txtboxSalFamilia);
            this.Controls.Add(this.txtboxAliqIRPF);
            this.Controls.Add(this.txtboxAliqINSS);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNomeFunc);
            this.Controls.Add(this.mskboxNomeFunc);
            this.Controls.Add(this.mskboxSalBruto);
            this.Controls.Add(this.NumUpDownFilhos);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.NumUpDownFilhos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown NumUpDownFilhos;
        private System.Windows.Forms.MaskedTextBox mskboxSalBruto;
        private System.Windows.Forms.MaskedTextBox mskboxNomeFunc;
        private System.Windows.Forms.Label lblNomeFunc;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.TextBox txtboxAliqINSS;
        private System.Windows.Forms.TextBox txtboxAliqIRPF;
        private System.Windows.Forms.TextBox txtboxSalFamilia;
        private System.Windows.Forms.TextBox txtboxDescIRPF;
        private System.Windows.Forms.TextBox txtboxDescINSS;
        private System.Windows.Forms.TextBox txtboxSalLiquido;
        private System.Windows.Forms.Label lblAliqINSS;
        private System.Windows.Forms.Label lblAliqIRPF;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblSalLiquido;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
    }
}

