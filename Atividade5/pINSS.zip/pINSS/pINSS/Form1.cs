﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pINSS
{
    public partial class Form1 : Form
    {
        double DescINSS, DescIRPF, SalFamilia, SalLiquido, SalBruto;
        decimal filhos;

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtboxSalLiquido.Clear();
            txtboxSalFamilia.Clear();
            txtboxAliqINSS.Clear();
            txtboxAliqIRPF.Clear();
            txtboxDescINSS.Clear();
            txtboxDescIRPF.Clear();
            mskboxNomeFunc.Clear();
            mskboxSalBruto.Clear();
            NumUpDownFilhos.Value = 0;
            DescINSS = 0;
            DescIRPF = 0;
            SalFamilia = 0;
            SalLiquido = 0;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void mskboxSalBruto_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(mskboxSalBruto, "");
            double salBruto;

            if(!double.TryParse(mskboxSalBruto.Text, out salBruto))
            {
                errorProvider1.SetError(mskboxSalBruto, "Digite o salário bruto!");
            }
            else if(salBruto <= 0)
            {
                errorProvider1.SetError(mskboxSalBruto, "Digite um valor maior que zero!");
            }
        }

        private void mskboxNomeFunc_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(mskboxNomeFunc, "");

            if (!Regex.IsMatch(mskboxNomeFunc.Text, @"^[a-zA-Z\s]+$"))
            {
                errorProvider2.SetError(mskboxNomeFunc, "Por favor digite apenas letras!");
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            filhos = NumUpDownFilhos.Value;
            SalBruto = double.Parse(mskboxSalBruto.Text);

            //Cálculo INSS

            if (SalBruto <= 800.47)
            {
                txtboxAliqINSS.Text = "7,65%";
                DescINSS = SalBruto * 0.0765;
                txtboxDescINSS.Text = DescINSS.ToString();
            }
            else if (SalBruto <= 1050)
            {
                txtboxAliqINSS.Text = "8,65%";
                DescINSS = SalBruto * 0.0865;
                txtboxDescINSS.Text = DescINSS.ToString();
            }
            else if (SalBruto <= 1400.77)
            {
                txtboxAliqINSS.Text = "9,00%";
                DescINSS = SalBruto * 0.09;
                txtboxDescINSS.Text = DescINSS.ToString();
            }
            else if (SalBruto <= 2801.56)
            {
                txtboxAliqINSS.Text = "11,00%";
                DescINSS = SalBruto * 0.11;
                txtboxDescINSS.Text = DescINSS.ToString();
            }
            else
            {
                txtboxAliqINSS.Text = "Teto";
                DescINSS = 308.17;
                txtboxDescINSS.Text = DescINSS.ToString();
            }

            //Cálculo IRPF

            if (SalBruto <= 1257.12)
            {
                txtboxAliqIRPF.Text = "Isento";
                txtboxDescIRPF.Text = "0,00";
            }
            else if (SalBruto <= 2512.08)
            {
                txtboxAliqIRPF.Text = "15,00%";
                DescIRPF = SalBruto * 0.15;
                txtboxDescIRPF.Text = DescIRPF.ToString();
            }
            else
            {
                txtboxAliqIRPF.Text = "27,50%";
                DescIRPF = SalBruto * 0.275;
                txtboxDescIRPF.Text = DescIRPF.ToString();
            }

            //Cálculo Salário Família

            if (SalBruto <= 435.52 && filhos > 0)
            {
                SalFamilia = 22.33 * ((int)filhos);
                txtboxSalFamilia.Text = SalFamilia.ToString();
            }
            else if (SalBruto <= 654.61 && filhos > 0)
            {
                SalFamilia = 15.74 * ((int)filhos);
                txtboxSalFamilia.Text = SalFamilia.ToString();
            }
            else
            {
                SalFamilia = 0;
                txtboxSalFamilia.Text = "0,00";
            }

            //Cálculo Salário Líquido

            SalLiquido = SalBruto - DescINSS - DescIRPF + SalFamilia;
            txtboxSalLiquido.Text = SalLiquido.ToString();
        }
    }
}
